module.exports = {
    delay: 3000, // Delay antar pesan (ms)
    message: 'Halo, ini pesan otomatis dari BOT Push Kontak!',
    mediaFile: null // Atau 'media/gambar.jpg' jika ingin kirim media
};
