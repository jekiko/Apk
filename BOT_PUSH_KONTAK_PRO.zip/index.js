const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const fs = require('fs-extra');
const chalk = require('chalk');
const config = require('./config');
const logger = require('./utils/logger');
const contactHelper = require('./utils/contactHelper');

const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: { headless: true }
});

client.on('qr', qr => {
    qrcode.generate(qr, { small: true });
    console.log(chalk.yellow('[!] Scan QR dengan WhatsApp kamu'));
});

client.on('ready', async () => {
    console.log(chalk.green('[✔] WhatsApp siap digunakan'));

    const contacts = await contactHelper.loadContacts();
    const message = config.message;
    const delay = config.delay;

    for (let contact of contacts) {
        try {
            const chatId = contact.includes('@c.us') ? contact : `${contact}@c.us`;

            if (config.mediaFile) {
                const media = await MessageMedia.fromFilePath(config.mediaFile);
                await client.sendMessage(chatId, media, { caption: message });
            } else {
                await client.sendMessage(chatId, message);
            }

            logger.logSuccess(chatId);
            console.log(chalk.blue(`[✓] Pesan terkirim ke: ${chatId}`));
        } catch (err) {
            logger.logError(contact, err);
            console.log(chalk.red(`[✗] Gagal kirim ke: ${contact}`));
        }

        await new Promise(res => setTimeout(res, delay));
    }

    console.log(chalk.green('[✓] Push kontak selesai. Log tersimpan.'));
    process.exit(0);
});

client.on('auth_failure', () => {
    console.log(chalk.red('[!] Autentikasi gagal. Coba hapus folder session.'));
});

client.initialize();
