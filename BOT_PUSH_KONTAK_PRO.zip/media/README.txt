Tempat menyimpan file media (gambar/audio) untuk dikirim oleh bot.
