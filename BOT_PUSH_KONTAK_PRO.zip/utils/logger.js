const fs = require('fs-extra');
const successLog = './logs/success.log';
const errorLog = './logs/error.log';

module.exports = {
    logSuccess: (contact) => {
        fs.appendFileSync(successLog, `${contact}\n`);
    },
    logError: (contact, error) => {
        fs.appendFileSync(errorLog, `[${contact}] ${error.message}\n`);
    }
};
