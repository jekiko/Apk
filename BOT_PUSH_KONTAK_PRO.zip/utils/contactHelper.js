const fs = require('fs-extra');
const path = './data/contacts.json';

module.exports = {
    loadContacts: async () => {
        try {
            const data = await fs.readFile(path);
            return JSON.parse(data);
        } catch (err) {
            console.error('[!] Gagal memuat kontak:', err.message);
            return [];
        }
    }
};
